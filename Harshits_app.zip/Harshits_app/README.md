# Office-Portal
Office app with an admin side and an employee side. Based on android using Firebase database.
